# Handschrift. – kostenlos & privat

Eine einzelne statische HTML-Datei für einen kostenlosen Text-zu-Handschrift-Workflow.

## Datenschutz
- Keine externen JavaScript-Bibliotheken
- Kein Backend
- Keine Konten oder Zahlungen
- Text und Handschriftprofil werden nur lokal im Browser verarbeitet/gespeichert
- Der Scanner verarbeitet Fotos per Canvas im Browser und lädt sie nicht hoch

Hinweis: „Lokal“ ist keine Verschlüsselung. Andere Personen mit Zugriff auf dasselbe Browserprofil könnten lokale Browserdaten sehen.

## Online stellen mit GitHub Pages
1. Auf GitHub ein neues Repository anlegen, z. B. `handschrift-online`.
2. `index.html` und diese `README.md` hochladen.
3. Repository öffnen → **Settings** → **Pages**.
4. Bei **Build and deployment** als Quelle **Deploy from a branch** wählen.
5. Branch `main` und Ordner `/(root)` auswählen → **Save**.
6. Danach zeigt GitHub die öffentliche Website-Adresse an.

Mehr: https://docs.github.com/de/pages/getting-started-with-github-pages/creating-a-github-pages-site
